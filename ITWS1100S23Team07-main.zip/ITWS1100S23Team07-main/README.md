# ITWS1100S23Team07

How To use the App:
1. Top navigation bar can be used to navigate to the news and learn pages, those are the only links 
   in the navigation that work.
2. To get to our sign up pages and display pages, click on the get started or sign up button on 
   the landing page. Note, our display page only works with the Inexperienced Trader sign up option.
3. You can add new stocks to the display page using the search bar on the top right of the 
   display page
4. If either the news link or the learn link is clicked on the display page, you must navigate back
   to the landing page and restart the sign up process because we don't have a user authentication
   system.
Instance of the app can be found at : http://liw22rpi.eastus.cloudapp.azure.com/ITWS1100S23Team07